package homework_week_1;

public class Programme8_Divide {
    public static void main(String[] args){
        System.out.println("Test Data: 50/3");
        System.out.println("Expected Output: 16");
    }
}
