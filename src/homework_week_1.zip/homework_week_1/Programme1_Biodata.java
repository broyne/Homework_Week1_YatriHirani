package homework_week_1;

public class Programme1_Biodata {
    public static void main(String[] args) {
        System.out.println("BIO-DATA");
        System.out.print("Name:               ");
        System.out.println("Yatri Hirani");
        System.out.print("Father's Name:      ");
        System.out.println("Nathubhai Patel");
        System.out.print("Date of Birth:      ");
        System.out.println("04/02/1994");
        System.out.print("Height:             ");
        System.out.println("5'4''");
        System.out.print("Complexation:       ");
        System.out.println("Fair");
        System.out.print("Qualification:      ");
        System.out.println("B.E.");
        System.out.print("Language Known:     ");
        System.out.println("Gujarati , Hindi & English");
        System.out.print("Religion:           ");
        System.out.println("Hindu");
        System.out.print("Nationality:        ");
        System.out.println("Indian");
        System.out.print("Brother:            ");
        System.out.println("1 Younger");
        System.out.print("Address:            ");
        System.out.println("88-98 Marsden street Parramatta");
        System.out.print("Contact Number:     ");
        System.out.println("+6143393963");
    }
}
