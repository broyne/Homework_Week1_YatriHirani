package homework_week_1;

public class Programme9_Operations {
    public static void main(String[] args){
        System.out.println("Test Data: a. -5 + 8 * 6");
        System.out.println("           b. (55+9) % 9");
        System.out.println("           c. 20 + -3*5 / 8");
        System.out.println("           d. 5 + 15 / 3 * 2 - 8 % 3");

        System.out.println("Expected Output: 43");
        System.out.println("                 1");
        System.out.println("                 19");
        System.out.println("                 13");


    }
}
