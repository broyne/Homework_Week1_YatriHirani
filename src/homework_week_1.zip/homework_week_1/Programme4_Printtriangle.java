package homework_week_1;

public class Programme4_Printtriangle {
    public static void main (String[] args){
        System.out.println("*");
        System.out.println("**");
        System.out.println("***");
        System.out.println("****");
        System.out.println("*****");
        System.out.println("******");

    }
}
