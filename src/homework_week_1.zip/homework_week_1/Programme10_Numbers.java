package homework_week_1;

public class Programme10_Numbers {
    public static void main(String[] args){
        System.out.println("Test Data");
        System.out.println("Input first number: 25");
        System.out.println("Input Second number: 5");
        System.out.println("Expected Output: 25x5 = 125");

    }
}
