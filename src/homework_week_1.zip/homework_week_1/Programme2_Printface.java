package homework_week_1;

public class Programme2_Printface {
     public static void main(String[] args){
         System.out.println(" +!!!!!!!!!!+ ");
         System.out.println("[|   0 0   |]");
         System.out.println(" |    ^    | ");
         System.out.println(" |   !_!   | ");
         System.out.println(" +---------+ ");
     }
}
